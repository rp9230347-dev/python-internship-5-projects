"""Task 5 - Chat Application (Advanced) - SERVER
Threaded socket server with: user registration/login (PBKDF2-hashed passwords),
multiple rooms, and message history in SQLite.  Protocol = one JSON object per line.
Run: python advanced_server.py
"""
import hashlib
import hmac
import json
import os
import socket
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

HOST, PORT = "localhost", 5051
DB = Path(__file__).with_name("chat_history.db")
DEFAULT_ROOMS = ["general", "python", "random"]
lock = threading.Lock()
clients = {}  # conn -> {"user":..., "room":...}


# ------------------------------------------------------------ database
def db(sql, params=(), fetch=False):
    with sqlite3.connect(DB) as con:
        cur = con.execute(sql, params)
        return cur.fetchall() if fetch else None


def init_db():
    db("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, salt BLOB, pw_hash BLOB)")
    db("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, "
       "room TEXT, user TEXT, text TEXT, ts TEXT)")
    db("CREATE TABLE IF NOT EXISTS rooms (name TEXT PRIMARY KEY)")
    for r in DEFAULT_ROOMS:
        db("INSERT OR IGNORE INTO rooms (name) VALUES (?)", (r,))


def hash_pw(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120_000)


def register(user, password):
    if db("SELECT 1 FROM users WHERE username=?", (user,), fetch=True):
        return False
    salt = os.urandom(16)
    db("INSERT INTO users VALUES (?,?,?)", (user, salt, hash_pw(password, salt)))
    return True


def check_login(user, password):
    row = db("SELECT salt, pw_hash FROM users WHERE username=?", (user,), fetch=True)
    return bool(row) and hmac.compare_digest(row[0][1], hash_pw(password, row[0][0]))


# ------------------------------------------------------------ networking
def send(conn, obj):
    try:
        conn.sendall((json.dumps(obj) + "\n").encode("utf-8"))
    except OSError:
        pass


def broadcast_room(room, obj, skip=None):
    with lock:
        targets = [c for c, s in clients.items() if s["room"] == room and c is not skip]
    for c in targets:
        send(c, obj)


def room_users(room):
    with lock:
        return sorted(s["user"] for s in clients.values() if s["room"] == room and s["user"])


def join_room(conn, state, room):
    old = state["room"]
    if old:
        broadcast_room(old, {"type": "system", "text": f"{state['user']} left the room."}, skip=conn)
    state["room"] = room
    rows = db("SELECT user, text, ts FROM messages WHERE room=? ORDER BY id DESC LIMIT 50", (room,), fetch=True)
    send(conn, {"type": "joined", "room": room, "history": rows[::-1], "users": room_users(room)})
    broadcast_room(room, {"type": "system", "text": f"{state['user']} joined the room."}, skip=conn)


def handle(conn):
    state = {"user": None, "room": None}
    with lock:
        clients[conn] = state
    try:
        for line in conn.makefile("r", encoding="utf-8"):
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            kind = data.get("type")

            if kind in ("login", "register"):
                user, pw = str(data.get("user", "")).strip(), str(data.get("password", ""))
                if not user or len(pw) < 4:
                    send(conn, {"type": "auth", "ok": False, "error": "Username required and password min 4 chars."})
                elif kind == "register":
                    msg = "Registered! Now press Login." if register(user, pw) else "Username already taken."
                    send(conn, {"type": "auth", "ok": False, "error": msg})
                elif check_login(user, pw):
                    with lock:
                        already = any(s["user"] == user for s in clients.values())
                    if already:
                        send(conn, {"type": "auth", "ok": False, "error": "User already logged in."})
                    else:
                        state["user"] = user
                        rooms = [r[0] for r in db("SELECT name FROM rooms ORDER BY name", fetch=True)]
                        send(conn, {"type": "auth", "ok": True, "user": user, "rooms": rooms})
                else:
                    send(conn, {"type": "auth", "ok": False, "error": "Wrong username or password."})
                continue

            if not state["user"]:
                send(conn, {"type": "error", "text": "Please login first."})
            elif kind == "join":
                room = str(data.get("room", "")).strip().lower()[:30]
                if room:
                    db("INSERT OR IGNORE INTO rooms (name) VALUES (?)", (room,))
                    join_room(conn, state, room)
                    rooms = [r[0] for r in db("SELECT name FROM rooms ORDER BY name", fetch=True)]
                    with lock:
                        everyone = list(clients)
                    for c in everyone:
                        send(c, {"type": "rooms", "rooms": rooms})
            elif kind == "msg" and state["room"]:
                text = str(data.get("text", "")).strip()[:1000]
                if text:
                    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    db("INSERT INTO messages (room, user, text, ts) VALUES (?,?,?,?)",
                       (state["room"], state["user"], text, ts))
                    broadcast_room(state["room"], {"type": "msg", "user": state["user"], "text": text, "ts": ts})
    except (ConnectionError, OSError):
        pass
    finally:
        with lock:
            clients.pop(conn, None)
        if state["room"]:
            broadcast_room(state["room"], {"type": "system", "text": f"{state['user']} disconnected."})
        conn.close()


def main():
    init_db()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    print(f"Advanced chat server on {HOST}:{PORT}")
    try:
        while True:
            conn, _ = server.accept()
            threading.Thread(target=handle, args=(conn,), daemon=True).start()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
