"""Task 5 - Chat Application (Advanced) - GUI CLIENT (tkinter)
Login/Register -> choose room -> chat with history.  Start advanced_server.py first.
Run: python advanced_client.py   (open several windows to test)
"""
import json
import queue
import socket
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

HOST, PORT = "localhost", 5051


class ChatClient(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Chat App")
        self.geometry("720x480")
        self.inbox = queue.Queue()
        self.sock = None
        self.user = None
        self.build_login()
        self.after(100, self.poll)

    # ---------------- networking
    def connect(self):
        if self.sock:
            return True
        try:
            self.sock = socket.create_connection((HOST, PORT), timeout=5)
            self.sock.settimeout(None)
        except OSError:
            messagebox.showerror("Connection", "Cannot connect. Is advanced_server.py running?")
            self.sock = None
            return False
        threading.Thread(target=self.reader, daemon=True).start()
        return True

    def reader(self):
        try:
            for line in self.sock.makefile("r", encoding="utf-8"):
                self.inbox.put(json.loads(line))
        except (OSError, ValueError):
            pass
        self.inbox.put({"type": "closed"})

    def send(self, obj):
        try:
            self.sock.sendall((json.dumps(obj) + "\n").encode("utf-8"))
        except (OSError, AttributeError):
            messagebox.showerror("Connection", "Connection lost.")

    # ---------------- login screen
    def build_login(self):
        self.login = ttk.Frame(self, padding=40)
        self.login.pack(expand=True)
        ttk.Label(self.login, text="Chat Login", font=("Arial", 18, "bold")).grid(columnspan=2, pady=10)
        ttk.Label(self.login, text="Username").grid(row=1, column=0, sticky="w")
        self.u = ttk.Entry(self.login)
        self.u.grid(row=1, column=1, pady=4)
        ttk.Label(self.login, text="Password").grid(row=2, column=0, sticky="w")
        self.p = ttk.Entry(self.login, show="*")
        self.p.grid(row=2, column=1, pady=4)
        self.p.bind("<Return>", lambda e: self.auth("login"))
        row = ttk.Frame(self.login)
        row.grid(row=3, columnspan=2, pady=10)
        ttk.Button(row, text="Login", command=lambda: self.auth("login")).pack(side="left", padx=4)
        ttk.Button(row, text="Register", command=lambda: self.auth("register")).pack(side="left", padx=4)
        self.msg = ttk.Label(self.login, text="", foreground="#c62828")
        self.msg.grid(row=4, columnspan=2)

    def auth(self, kind):
        if self.connect():
            self.send({"type": kind, "user": self.u.get().strip(), "password": self.p.get()})

    # ---------------- chat screen
    def build_chat(self, rooms):
        self.login.destroy()
        side = ttk.Frame(self, padding=6)
        side.pack(side="left", fill="y")
        ttk.Label(side, text=f"Hi, {self.user}", font=("Arial", 11, "bold")).pack(anchor="w")
        ttk.Label(side, text="Rooms").pack(anchor="w", pady=(8, 0))
        self.room_list = tk.Listbox(side, height=8, exportselection=False)
        self.room_list.pack(fill="y")
        self.room_list.bind("<<ListboxSelect>>", self.on_room)
        ttk.Button(side, text="+ New room", command=self.new_room).pack(fill="x", pady=4)
        ttk.Label(side, text="Online here").pack(anchor="w", pady=(8, 0))
        self.users_list = tk.Listbox(side, height=8)
        self.users_list.pack(fill="y")
        self.set_rooms(rooms)

        main = ttk.Frame(self, padding=6)
        main.pack(side="left", fill="both", expand=True)
        self.room_lbl = ttk.Label(main, text="Select a room", font=("Arial", 12, "bold"))
        self.room_lbl.pack(anchor="w")
        self.text = tk.Text(main, state="disabled", wrap="word")
        self.text.pack(fill="both", expand=True)
        self.text.tag_config("sys", foreground="#757575")
        self.text.tag_config("me", foreground="#1565c0")
        bottom = ttk.Frame(main)
        bottom.pack(fill="x", pady=4)
        self.entry = ttk.Entry(bottom)
        self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", lambda e: self.send_msg())
        ttk.Button(bottom, text="Send", command=self.send_msg).pack(side="left", padx=4)

    def set_rooms(self, rooms):
        self.room_list.delete(0, "end")
        for r in rooms:
            self.room_list.insert("end", r)

    def on_room(self, _):
        sel = self.room_list.curselection()
        if sel:
            self.send({"type": "join", "room": self.room_list.get(sel[0])})

    def new_room(self):
        name = simpledialog.askstring("New room", "Room name:")
        if name:
            self.send({"type": "join", "room": name})

    def send_msg(self):
        text = self.entry.get().strip()
        if text:
            self.send({"type": "msg", "text": text})
            self.entry.delete(0, "end")

    def add_line(self, line, tag=None):
        self.text.config(state="normal")
        self.text.insert("end", line + "\n", tag)
        self.text.config(state="disabled")
        self.text.see("end")

    # ---------------- message pump
    def poll(self):
        while not self.inbox.empty():
            m = self.inbox.get()
            t = m.get("type")
            if t == "auth":
                if m["ok"]:
                    self.user = m["user"]
                    self.build_chat(m["rooms"])
                else:
                    self.msg.config(text=m["error"])
            elif t == "rooms":
                self.set_rooms(m["rooms"])
            elif t == "joined":
                self.room_lbl.config(text=f"# {m['room']}")
                self.text.config(state="normal")
                self.text.delete("1.0", "end")
                self.text.config(state="disabled")
                for user, text, ts in m["history"]:
                    self.add_line(f"[{ts[11:16]}] {user}: {text}")
                self.add_line("--- end of history ---", "sys")
                self.users_list.delete(0, "end")
                for u in m["users"]:
                    self.users_list.insert("end", u)
            elif t == "msg":
                self.add_line(f"[{m['ts'][11:16]}] {m['user']}: {m['text']}", "me" if m["user"] == self.user else None)
            elif t == "system":
                self.add_line(m["text"], "sys")
            elif t == "error":
                messagebox.showwarning("Chat", m["text"])
            elif t == "closed":
                messagebox.showinfo("Chat", "Disconnected from server.")
                self.destroy()
                return
        self.after(100, self.poll)


if __name__ == "__main__":
    ChatClient().mainloop()
