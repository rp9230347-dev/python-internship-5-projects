"""Task 5 - Chat Application (Beginner) - CLIENT
Run in two separate terminals:  python beginner_client.py
Type /quit to leave.
"""
import socket
import threading
from datetime import datetime

HOST, PORT = "localhost", 5050


def receive(sock):
    try:
        for line in sock.makefile("r", encoding="utf-8"):
            print("\r" + line.strip() + "\n> ", end="", flush=True)
    except OSError:
        pass
    print("\nDisconnected from server.")


def main():
    name = input("Your name: ").strip() or "Guest"
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((HOST, PORT))
    except ConnectionRefusedError:
        print("Cannot connect. Start beginner_server.py first.")
        return
    sock.sendall((name + "\n").encode("utf-8"))
    threading.Thread(target=receive, args=(sock,), daemon=True).start()
    print("Connected! Type messages and press Enter. /quit to exit.")
    try:
        while True:
            text = input("> ").strip()
            if text == "/quit":
                break
            if text:
                sock.sendall((text + "\n").encode("utf-8"))
                print(f"[{datetime.now().strftime('%H:%M')}] You: {text}")
    except (KeyboardInterrupt, EOFError, OSError):
        pass
    finally:
        sock.close()


if __name__ == "__main__":
    main()
