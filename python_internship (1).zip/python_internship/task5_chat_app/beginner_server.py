"""Task 5 - Chat Application (Beginner) - SERVER
Two-user command-line chat using socket + threading.
Start this first:  python beginner_server.py
"""
import socket
import threading
from datetime import datetime

HOST, PORT = "localhost", 5050
clients = {}  # socket -> name
lock = threading.Lock()


def stamp(text):
    return f"[{datetime.now().strftime('%H:%M')}] {text}"


def send_to_others(sender, message):
    with lock:
        targets = [c for c in clients if c is not sender]
    for c in targets:
        try:
            c.sendall((message + "\n").encode("utf-8"))
        except OSError:
            pass


def handle_client(conn):
    name = "Unknown"
    try:
        f = conn.makefile("r", encoding="utf-8")
        name = (f.readline().strip() or "Guest")
        with lock:
            clients[conn] = name
        print(stamp(f"{name} connected"))
        send_to_others(conn, stamp(f"* {name} joined the chat *"))
        for line in f:
            text = line.strip()
            if text:
                msg = stamp(f"{name}: {text}")
                print(msg)
                send_to_others(conn, msg)
    except (ConnectionError, OSError):
        pass
    finally:  # graceful disconnection: tell the other client
        with lock:
            clients.pop(conn, None)
        send_to_others(conn, stamp(f"* {name} has disconnected *"))
        print(stamp(f"{name} disconnected"))
        conn.close()


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(2)
    print(f"Server listening on {HOST}:{PORT} ... (Ctrl+C to stop)")
    try:
        while True:
            conn, addr = server.accept()
            with lock:
                full = len(clients) >= 2
            if full:
                conn.sendall(b"Chat is full (2 users max).\n")
                conn.close()
                continue
            threading.Thread(target=handle_client, args=(conn,), daemon=True).start()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
