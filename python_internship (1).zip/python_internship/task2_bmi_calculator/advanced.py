"""Task 2 - BMI Calculator (Advanced)
tkinter GUI + SQLite history + multi-user + matplotlib trend chart + DB error handling.
Run: python advanced.py
"""
import sqlite3
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

DB_PATH = Path(__file__).with_name("bmi_records.db")
COLORS = {"Underweight": "#1976d2", "Normal": "#2e7d32", "Overweight": "#ef6c00", "Obese": "#c62828"}


def classify(bmi):
    if bmi < 18.5:
        return "Underweight"
    if bmi < 25:
        return "Normal"
    if bmi < 30:
        return "Overweight"
    return "Obese"


class Database:
    def __init__(self, path):
        self.path = path
        self.execute("""CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT NOT NULL,
            weight REAL, height REAL, bmi REAL, category TEXT, created TEXT)""")

    def execute(self, sql, params=(), fetch=False):
        with sqlite3.connect(self.path) as con:
            cur = con.execute(sql, params)
            return cur.fetchall() if fetch else None

    def add(self, user, weight, height, bmi, category):
        self.execute("INSERT INTO records (user, weight, height, bmi, category, created) VALUES (?,?,?,?,?,?)",
                     (user, weight, height, bmi, category, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

    def users(self):
        return [r[0] for r in self.execute("SELECT DISTINCT user FROM records ORDER BY user", fetch=True)]

    def history(self, user):
        return self.execute("SELECT created, weight, height, bmi, category FROM records "
                            "WHERE user=? ORDER BY id", (user,), fetch=True)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BMI Calculator")
        self.geometry("640x640")
        try:
            self.db = Database(DB_PATH)
        except sqlite3.Error as e:
            messagebox.showerror("Database error", f"Cannot open database:\n{e}")
            self.destroy()
            raise SystemExit

        form = ttk.Frame(self, padding=12)
        form.pack(fill="x")
        ttk.Label(form, text="User name:").grid(row=0, column=0, sticky="w", pady=3)
        self.user_var = tk.StringVar()
        self.user_box = ttk.Combobox(form, textvariable=self.user_var, values=self.safe_users())
        self.user_box.grid(row=0, column=1, sticky="ew")
        ttk.Label(form, text="Weight (kg):").grid(row=1, column=0, sticky="w", pady=3)
        self.weight = ttk.Entry(form)
        self.weight.grid(row=1, column=1, sticky="ew")
        ttk.Label(form, text="Height (m):").grid(row=2, column=0, sticky="w", pady=3)
        self.height = ttk.Entry(form)
        self.height.grid(row=2, column=1, sticky="ew")
        form.columnconfigure(1, weight=1)

        btns = ttk.Frame(self, padding=(12, 0))
        btns.pack(fill="x")
        ttk.Button(btns, text="Calculate", command=self.calculate).pack(side="left", padx=3)
        ttk.Button(btns, text="Show history", command=self.show_history).pack(side="left", padx=3)
        ttk.Button(btns, text="Show graph", command=self.show_graph).pack(side="left", padx=3)

        self.result = tk.Label(self, text="Enter details and press Calculate", font=("Arial", 16, "bold"), pady=10)
        self.result.pack(fill="x")

        self.table = ttk.Treeview(self, columns=("date", "weight", "height", "bmi", "cat"), show="headings", height=6)
        for col, text in zip(self.table["columns"], ("Date", "Weight", "Height", "BMI", "Category")):
            self.table.heading(col, text=text)
            self.table.column(col, width=100)
        self.table.pack(fill="x", padx=12)

        self.fig = Figure(figsize=(5, 3), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=12, pady=8)

    def safe_users(self):
        try:
            return self.db.users()
        except sqlite3.Error:
            return []

    def read_inputs(self):
        user = self.user_var.get().strip()
        if not user:
            raise ValueError("Please enter a user name.")
        try:
            w, h = float(self.weight.get()), float(self.height.get())
        except ValueError:
            raise ValueError("Weight and height must be numbers.")
        if w <= 0 or h <= 0:
            raise ValueError("Weight and height must be positive.")
        if h > 3:
            raise ValueError("Height must be in metres (e.g. 1.70).")
        return user, w, h

    def calculate(self):
        try:
            user, w, h = self.read_inputs()
        except ValueError as e:
            messagebox.showwarning("Invalid input", str(e))
            return
        bmi = round(w / h ** 2, 2)
        cat = classify(bmi)
        self.result.config(text=f"BMI: {bmi:.2f}  ({cat})", fg="white", bg=COLORS[cat])
        try:
            self.db.add(user, w, h, bmi, cat)
            self.user_box["values"] = self.safe_users()
            self.show_history()
        except sqlite3.Error as e:
            messagebox.showerror("Database error", f"Could not save record:\n{e}")

    def show_history(self):
        user = self.user_var.get().strip()
        self.table.delete(*self.table.get_children())
        if not user:
            return
        try:
            for row in self.db.history(user):
                self.table.insert("", "end", values=row)
        except sqlite3.Error as e:
            messagebox.showerror("Database error", f"Could not read records:\n{e}")

    def show_graph(self):
        user = self.user_var.get().strip()
        if not user:
            messagebox.showinfo("Graph", "Enter a user name first.")
            return
        try:
            rows = self.db.history(user)
        except sqlite3.Error as e:
            messagebox.showerror("Database error", f"Could not read records:\n{e}")
            return
        if not rows:
            messagebox.showinfo("Graph", "No records for this user yet.")
            return
        self.ax.clear()
        self.ax.plot(range(1, len(rows) + 1), [r[3] for r in rows], marker="o")
        self.ax.axhspan(18.5, 24.9, alpha=0.15, color="green", label="Normal range")
        self.ax.set_title(f"BMI trend - {user}")
        self.ax.set_xlabel("Record #")
        self.ax.set_ylabel("BMI")
        self.ax.legend()
        self.fig.tight_layout()
        self.canvas.draw()


if __name__ == "__main__":
    App().mainloop()
