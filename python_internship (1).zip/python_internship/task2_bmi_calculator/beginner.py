"""Task 2 - BMI Calculator (Beginner, command line)
Run: python beginner.py
"""


def classify(bmi):
    if bmi < 18.5:
        return "Underweight"
    if bmi < 25:
        return "Normal"
    if bmi < 30:
        return "Overweight"
    return "Obese"


def get_positive_number(prompt):
    """Keep asking until the user enters a valid positive number."""
    while True:
        raw = input(prompt).strip()
        try:
            value = float(raw)
        except ValueError:
            print("Error: please enter a number (e.g. 65 or 1.72).")
            continue
        if value <= 0:
            print("Error: value must be greater than zero.")
            continue
        return value


def main():
    print("=== BMI Calculator ===")
    while True:
        weight = get_positive_number("Enter weight in kg: ")
        height = get_positive_number("Enter height in metres (e.g. 1.70): ")
        if height > 3:
            print("Height looks like centimetres. Please enter it in metres (e.g. 1.70).")
            continue
        bmi = weight / (height ** 2)
        print(f"Your BMI is {bmi:.2f} -> {classify(bmi)}")
        if input("Calculate again? (y/n): ").strip().lower() != "y":
            break


if __name__ == "__main__":
    main()
