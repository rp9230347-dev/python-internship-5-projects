"""Task 3 - Random Password Generator (Beginner, command line)
Uses random + string. Run: python beginner.py
"""
import random
import string


def ask_length():
    while True:
        raw = input("Password length (minimum 8): ").strip()
        if not raw.isdigit():
            print("Error: enter a whole number.")
        elif int(raw) < 8:
            print("Error: minimum length is 8.")
        elif int(raw) > 128:
            print("Error: maximum length is 128.")
        else:
            return int(raw)


def ask_yes_no(question):
    return input(question + " (y/n): ").strip().lower() == "y"


def ask_types():
    while True:
        chosen = {}
        if ask_yes_no("Include uppercase letters?"):
            chosen["upper"] = string.ascii_uppercase
        if ask_yes_no("Include lowercase letters?"):
            chosen["lower"] = string.ascii_lowercase
        if ask_yes_no("Include numbers?"):
            chosen["digits"] = string.digits
        if ask_yes_no("Include symbols?"):
            chosen["symbols"] = string.punctuation
        if len(chosen) >= 2:
            return chosen
        print("Error: select at least 2 character types. Try again.\n")


def generate(length, chosen):
    # guarantee one character from each selected type, then fill the rest
    chars = [random.choice(pool) for pool in chosen.values()]
    all_chars = "".join(chosen.values())
    chars += [random.choice(all_chars) for _ in range(length - len(chars))]
    random.shuffle(chars)
    return "".join(chars)


def main():
    print("=== Random Password Generator ===")
    while True:
        length = ask_length()
        chosen = ask_types()
        print("\nGenerated password:", generate(length, chosen), "\n")
        if not ask_yes_no("Generate another password?"):
            break


if __name__ == "__main__":
    main()
