"""Task 3 - Random Password Generator (Advanced)
tkinter GUI, secrets module, strength indicator, guaranteed char types, pyperclip auto-copy,
exclude ambiguous chars, last-5 history (memory only - never saved to disk).
Run: python advanced.py
"""
import secrets
import string
import tkinter as tk
from tkinter import messagebox, ttk

try:
    import pyperclip
except ImportError:  # app still works, copy just warns
    pyperclip = None

AMBIGUOUS = set("0Oo1lI|")


def build_pools(upper, lower, digits, symbols, exclude_ambiguous):
    pools = []
    if upper:
        pools.append(string.ascii_uppercase)
    if lower:
        pools.append(string.ascii_lowercase)
    if digits:
        pools.append(string.digits)
    if symbols:
        pools.append("!@#$%^&*()-_=+[]{};:,.<>?")
    if exclude_ambiguous:
        pools = ["".join(c for c in p if c not in AMBIGUOUS) for p in pools]
    return pools


def generate_password(length, pools):
    """Cryptographically secure; guarantees >=1 char from each selected pool."""
    chars = [secrets.choice(p) for p in pools]
    everything = "".join(pools)
    chars += [secrets.choice(everything) for _ in range(length - len(chars))]
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)


def strength(password):
    kinds = sum([any(c.islower() for c in password), any(c.isupper() for c in password),
                 any(c.isdigit() for c in password), any(not c.isalnum() for c in password)])
    score = (len(password) >= 8) + (len(password) >= 12) + (len(password) >= 16) + kinds
    if score <= 3:
        return "Weak", 33, "#c62828"
    if score <= 5:
        return "Medium", 66, "#ef6c00"
    return "Strong", 100, "#2e7d32"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Password Generator")
        self.geometry("460x560")
        self.history = []

        frm = ttk.Frame(self, padding=14)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="Length:").grid(row=0, column=0, sticky="w")
        self.length = tk.IntVar(value=12)
        ttk.Scale(frm, from_=8, to=64, orient="horizontal", variable=self.length,
                  command=lambda v: self.length.set(int(float(v)))).grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Spinbox(frm, from_=8, to=64, textvariable=self.length, width=5).grid(row=0, column=2)

        self.opts = {name: tk.BooleanVar(value=default) for name, default in
                     [("Uppercase", True), ("Lowercase", True), ("Numbers", True), ("Symbols", True),
                      ("Exclude ambiguous (0 O 1 l I)", False)]}
        for i, (name, var) in enumerate(self.opts.items(), start=1):
            ttk.Checkbutton(frm, text=name, variable=var).grid(row=i, column=0, columnspan=3, sticky="w", pady=1)

        ttk.Button(frm, text="Generate (auto-copies)", command=self.generate).grid(
            row=6, column=0, columnspan=3, sticky="ew", pady=10)

        self.out = tk.StringVar()
        ttk.Entry(frm, textvariable=self.out, font=("Consolas", 14), justify="center").grid(
            row=7, column=0, columnspan=3, sticky="ew")
        ttk.Button(frm, text="Copy to Clipboard", command=self.copy).grid(
            row=8, column=0, columnspan=3, sticky="ew", pady=6)

        self.bar = ttk.Progressbar(frm, maximum=100)
        self.bar.grid(row=9, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        self.label = tk.Label(frm, text="Strength: -", font=("Arial", 11, "bold"))
        self.label.grid(row=10, column=0, columnspan=3)

        ttk.Label(frm, text="Last 5 passwords (this session only):").grid(
            row=11, column=0, columnspan=3, sticky="w", pady=(12, 2))
        self.hist_box = tk.Listbox(frm, height=5, font=("Consolas", 10))
        self.hist_box.grid(row=12, column=0, columnspan=3, sticky="ew")
        frm.columnconfigure(1, weight=1)

    def generate(self):
        o = list(self.opts.values())
        pools = build_pools(o[0].get(), o[1].get(), o[2].get(), o[3].get(), o[4].get())
        if not pools:
            messagebox.showwarning("Select type", "Select at least one character type.")
            return
        length = self.length.get()
        if not 8 <= length <= 64:
            messagebox.showwarning("Length", "Length must be between 8 and 64.")
            return
        pwd = generate_password(length, pools)
        self.out.set(pwd)
        label, value, color = strength(pwd)
        self.bar["value"] = value
        self.label.config(text=f"Strength: {label}", fg=color)
        self.history = ([pwd] + self.history)[:5]
        self.hist_box.delete(0, "end")
        for p in self.history:
            self.hist_box.insert("end", p)
        self.copy(silent=True)

    def copy(self, silent=False):
        if not self.out.get():
            return
        if pyperclip is None:
            if not silent:
                messagebox.showinfo("Clipboard", "Install pyperclip: pip install pyperclip")
            return
        try:
            pyperclip.copy(self.out.get())
        except pyperclip.PyperclipException as e:
            if not silent:
                messagebox.showerror("Clipboard", str(e))


if __name__ == "__main__":
    App().mainloop()
