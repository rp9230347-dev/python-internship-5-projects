"""Task 1 - Voice Assistant (Advanced)
Includes every Beginner feature plus:
  * Natural-language intent understanding (scored intents + fuzzy matching + entity extraction)
  * Voice email via smtplib (use a TEST / dummy account)
  * Timed reminder with audible alert
  * Live weather (OpenWeatherMap free tier)
  * General-knowledge Q&A (local knowledge_base.json -> Wikipedia fallback)
  * Custom commands from custom_commands.json or by voice ("add command")
  * Privacy notes are in README.md

Run:   python advanced.py          (voice mode)
       python advanced.py --text   (type instead of speak, handy for testing)

Environment variables (never hard-code secrets):
  OPENWEATHER_API_KEY, SMTP_USER, SMTP_PASS, SMTP_HOST (default smtp.gmail.com), SMTP_PORT (587)
"""
import datetime
import difflib
import json
import os
import re
import smtplib
import sys
import threading
import webbrowser
from email.message import EmailMessage
from pathlib import Path

import requests

BASE = Path(__file__).parent
CUSTOM_FILE = BASE / "custom_commands.json"
KB_FILE = BASE / "knowledge_base.json"
TEXT_MODE = "--text" in sys.argv

# Contacts for voice email (use dummy addresses!)
CONTACTS = {"test": "your.test.account@example.com"}

if not TEXT_MODE:
    import pyttsx3
    import speech_recognition as sr
    engine = pyttsx3.init()


# ---------------------------------------------------------------- I/O helpers
def speak(text):
    print("Assistant:", text)
    if not TEXT_MODE:
        engine.say(text)
        engine.runAndWait()


def listen():
    if TEXT_MODE:
        return input("You: ").strip().lower()
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        print("Listening...")
        try:
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=10)
        except sr.WaitTimeoutError:
            speak("I did not hear anything. Please repeat.")
            return ""
    try:
        text = recognizer.recognize_google(audio).lower()
        print("You said:", text)
        return text
    except sr.UnknownValueError:
        speak("Sorry, I could not understand. Please repeat.")
    except sr.RequestError:
        speak("Speech service is not available right now.")
    return ""


# ---------------------------------------------------------------- NLU
# Each intent has trigger words/phrases. Score = matched words (with fuzzy matching
# so small recognition errors still work) -> highest score wins.
INTENTS = {
    "greet": ["hello", "hi", "hey", "good morning", "good evening"],
    "time": ["time", "clock", "what time", "current time"],
    "date": ["date", "day today", "today's date", "what day"],
    "search": ["search", "google", "look up", "find information"],
    "email": ["email", "mail", "send message", "compose"],
    "reminder": ["remind", "reminder", "alarm", "timer", "alert me"],
    "weather": ["weather", "temperature", "forecast", "rain", "hot outside"],
    "add_command": ["add command", "new command", "teach you"],
    "exit": ["exit", "quit", "stop", "bye", "goodbye"],
}


def _fuzzy_has(word, text_words):
    return bool(difflib.get_close_matches(word, text_words, n=1, cutoff=0.82))


def detect_intent(text):
    words = re.findall(r"[a-z']+", text)
    best, best_score = None, 0
    for intent, keys in INTENTS.items():
        score = 0
        for key in keys:
            if " " in key:
                score += 2 if key in text else 0
            elif _fuzzy_has(key, words):
                score += 1
        if score > best_score:
            best, best_score = intent, score
    return best


def extract_number_of_seconds(text):
    """'in 2 minutes', 'after 30 seconds', '1 hour' -> seconds"""
    m = re.search(r"(\d+)\s*(second|sec|minute|min|hour|hr)", text)
    if not m:
        return None
    n, unit = int(m.group(1)), m.group(2)
    return n * (3600 if unit.startswith(("hour", "hr")) else 60 if unit.startswith("min") else 1)


# ---------------------------------------------------------------- actions
def do_time():
    speak("The time is " + datetime.datetime.now().strftime("%I:%M %p"))


def do_date():
    speak("Today is " + datetime.datetime.now().strftime("%A, %d %B %Y"))


def do_search(text):
    topic = re.sub(r"^.*?(search|google|look up|find information)( for| about| on)?", "", text).strip()
    if not topic:
        speak("What should I search for?")
        topic = listen()
    if topic:
        speak("Searching for " + topic)
        webbrowser.open("https://www.google.com/search?q=" + topic.replace(" ", "+"))


def do_weather(text):
    key = os.getenv("OPENWEATHER_API_KEY")
    if not key:
        speak("Please set the OPENWEATHER_API_KEY environment variable first.")
        return
    m = re.search(r"\b(?:in|of|at|for)\s+([a-z ]+)$", text)
    city = m.group(1).strip() if m else None
    if not city:
        speak("Which city?")
        city = listen()
    if not city:
        return
    try:
        r = requests.get("https://api.openweathermap.org/data/2.5/weather",
                         params={"q": city, "appid": key, "units": "metric"}, timeout=8)
        if r.status_code == 404:
            speak("I could not find that city.")
        elif r.status_code == 401:
            speak("The weather API key is invalid.")
        else:
            d = r.json()
            speak(f"In {d['name']} it is {round(d['main']['temp'])} degrees Celsius with "
                  f"{d['weather'][0]['description']}. Humidity is {d['main']['humidity']} percent.")
    except requests.RequestException:
        speak("I could not reach the weather service.")


def do_email():
    user, pwd = os.getenv("SMTP_USER"), os.getenv("SMTP_PASS")
    if not (user and pwd):
        speak("Please set SMTP_USER and SMTP_PASS environment variables for a test account.")
        return
    speak("Who is the recipient? Say a contact name.")
    name = listen()
    to = CONTACTS.get(name)
    if not to:
        speak("I do not have that contact. Add it to the CONTACTS list.")
        return
    speak("What is the subject?")
    subject = listen()
    speak("What is the message?")
    body = listen()
    if not (subject and body):
        speak("Email cancelled.")
        return
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = user, to, subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(os.getenv("SMTP_HOST", "smtp.gmail.com"), int(os.getenv("SMTP_PORT", 587))) as s:
            s.starttls()
            s.login(user, pwd)
            s.send_message(msg)
        speak("Email sent.")
    except Exception as exc:  # smtplib raises many error types
        speak("Could not send the email.")
        print("Email error:", exc)


def do_reminder(text):
    seconds = extract_number_of_seconds(text)
    if seconds is None:
        speak("After how long? For example, say 2 minutes.")
        seconds = extract_number_of_seconds(listen() or "")
    if seconds is None:
        speak("Sorry, I could not understand the duration.")
        return
    label = re.sub(r".*?(remind me|reminder|alarm|timer)( to| for| about)?", "", text)
    label = re.sub(r"(in|after)?\s*\d+\s*\w+", "", label).strip() or "your reminder"

    def alert():
        print("\a")
        for _ in range(2):
            speak("Reminder! " + label)

    threading.Timer(seconds, alert).start()
    speak(f"Okay, I will remind you in {seconds} seconds.")


def do_qa(text):
    """Local knowledge base first, Wikipedia as a fallback."""
    try:
        kb = json.loads(KB_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        kb = {}
    match = difflib.get_close_matches(text, kb.keys(), n=1, cutoff=0.6)
    if match:
        speak(kb[match[0]])
        return True
    topic = re.sub(r"^(what is|what are|who is|who was|tell me about|explain)\s+(a |an |the )?", "", text).strip()
    if not topic:
        return False
    try:
        r = requests.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + topic.replace(" ", "_"), timeout=8)
        if r.status_code == 200 and r.json().get("extract"):
            speak(r.json()["extract"].split(". ")[0] + ".")
            return True
    except requests.RequestException:
        pass
    return False


# ---------------------------------------------------------------- custom commands
def load_custom():
    try:
        return json.loads(CUSTOM_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def run_custom(text):
    cmds = load_custom()
    match = difflib.get_close_matches(text, cmds.keys(), n=1, cutoff=0.8)
    if not match:
        return False
    action = cmds[match[0]]
    if action["type"] == "open_url":
        speak("Opening " + match[0].replace("open ", ""))
        webbrowser.open(action["value"])
    else:
        speak(action["value"])
    return True


def add_custom_command():
    speak("What phrase should trigger the command?")
    phrase = listen()
    speak("What should I say back when you use it?")
    reply = listen()
    if phrase and reply:
        cmds = load_custom()
        cmds[phrase] = {"type": "say", "value": reply}
        CUSTOM_FILE.write_text(json.dumps(cmds, indent=2), encoding="utf-8")
        speak("Command saved.")


# ---------------------------------------------------------------- main loop
def handle(text):
    if run_custom(text):
        return True
    intent = detect_intent(text)
    if intent == "greet":
        speak("Hello! How can I help you today?")
    elif intent == "time":
        do_time()
    elif intent == "date":
        do_date()
    elif intent == "search":
        do_search(text)
    elif intent == "weather":
        do_weather(text)
    elif intent == "email":
        do_email()
    elif intent == "reminder":
        do_reminder(text)
    elif intent == "add_command":
        add_custom_command()
    elif intent == "exit":
        speak("Goodbye!")
        return False
    elif not do_qa(text):
        speak("I am not sure about that. You can ask me to search it on the web.")
    return True


def main():
    speak("Advanced voice assistant ready.")
    running = True
    while running:
        try:
            text = listen()
        except OSError:
            print("Microphone not found. Use --text mode or install PyAudio.")
            break
        if text:
            running = handle(text)


if __name__ == "__main__":
    main()
