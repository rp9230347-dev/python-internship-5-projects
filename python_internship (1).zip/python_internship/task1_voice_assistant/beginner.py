"""Task 1 - Voice Assistant (Beginner)
Features: voice input, "hello" greeting, time/date, web search, error handling, text-to-speech.
Run:  python beginner.py
"""
import datetime
import webbrowser

import pyttsx3
import speech_recognition as sr

engine = pyttsx3.init()


def speak(text):
    """Print and speak the response (text-to-speech for ALL responses)."""
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()


def listen():
    """Capture microphone input and return lowercase text ('' on failure)."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        print("Listening...")
        try:
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=8)
        except sr.WaitTimeoutError:
            speak("I did not hear anything. Please repeat.")
            return ""
    try:
        text = recognizer.recognize_google(audio).lower()
        print("You said:", text)
        return text
    except sr.UnknownValueError:
        speak("Sorry, I could not understand. Please repeat.")
    except sr.RequestError:
        speak("Speech service is not available. Check your internet connection.")
    return ""


def handle(command):
    """Return False when the assistant should stop."""
    if "hello" in command or "hi" in command.split():
        speak("Hello! I am your voice assistant. How can I help you?")
    elif "time" in command:
        speak("The time is " + datetime.datetime.now().strftime("%I:%M %p"))
    elif "date" in command or "today" in command:
        speak("Today is " + datetime.datetime.now().strftime("%A, %d %B %Y"))
    elif "search" in command:
        topic = command.split("search", 1)[1].replace("for", "", 1).strip()
        if not topic:
            speak("What should I search for?")
            topic = listen()
        if topic:
            speak("Searching for " + topic)
            webbrowser.open("https://www.google.com/search?q=" + topic.replace(" ", "+"))
    elif any(w in command for w in ("exit", "quit", "stop", "bye")):
        speak("Goodbye!")
        return False
    elif command:
        speak("Sorry, I do not know that command yet.")
    return True


def main():
    speak("Voice assistant started. Say hello, ask the time or date, or say search for something.")
    running = True
    while running:
        try:
            command = listen()
        except OSError:
            print("Microphone not found. Install PyAudio and check your mic.")
            break
        if command:
            running = handle(command)


if __name__ == "__main__":
    main()
