"""Task 4 - Basic Weather App (Beginner, command line)
Needs a free OpenWeatherMap API key (openweathermap.org).
Set it once:  set OPENWEATHER_API_KEY=yourkey   (Windows)   export OPENWEATHER_API_KEY=yourkey  (Linux/Mac)
Run: python beginner.py
"""
import os

import requests

URL = "https://api.openweathermap.org/data/2.5/weather"
DEFAULT_COUNTRY = "IN"  # used for ZIP/PIN code lookups


def get_weather(query, api_key):
    params = {"appid": api_key, "units": "metric"}
    if query.isdigit():
        params["zip"] = f"{query},{DEFAULT_COUNTRY}"
    else:
        params["q"] = query
    try:
        resp = requests.get(URL, params=params, timeout=8)
    except requests.exceptions.Timeout:
        return None, "Network timeout. Please try again."
    except requests.exceptions.ConnectionError:
        return None, "No internet connection."
    except requests.exceptions.RequestException as e:
        return None, f"Request failed: {e}"

    if resp.status_code == 401:
        return None, "Invalid API key. (New keys can take ~1-2 hours to activate.)"
    if resp.status_code == 404:
        return None, "City not found. Check the spelling."
    if resp.status_code != 200:
        return None, f"API error {resp.status_code}."
    try:
        return resp.json(), None
    except ValueError:
        return None, "Received invalid data from the API."


def show(data):
    c = data["main"]["temp"]
    f = c * 9 / 5 + 32
    print(f"\nWeather in {data['name']}, {data['sys'].get('country', '')}")
    print(f"  Temperature : {c:.1f} °C / {f:.1f} °F")
    print(f"  Condition   : {data['weather'][0]['description'].title()}")
    print(f"  Humidity    : {data['main']['humidity']} %")
    print(f"  Wind speed  : {data['wind']['speed']} m/s\n")


def main():
    api_key = os.getenv("OPENWEATHER_API_KEY") or input("Enter your OpenWeatherMap API key: ").strip()
    print("=== Weather App ===")
    while True:
        query = input("Enter city name or ZIP/PIN code (or 'q' to quit): ").strip()
        if query.lower() == "q":
            break
        if not query:
            print("Error: input cannot be empty.")
            continue
        data, error = get_weather(query, api_key)
        print(error) if error else show(data)


if __name__ == "__main__":
    main()
