"""Task 4 - Basic Weather App (Advanced)
tkinter GUI + 5-day forecast + weather icons (Pillow) + °C/°F toggle + background threads.
Run: python advanced.py     (needs OPENWEATHER_API_KEY env var, or paste it in the app)
"""
import io
import os
import threading
import tkinter as tk
from collections import OrderedDict
from datetime import datetime
from tkinter import messagebox, ttk

import requests
from PIL import Image, ImageTk

BASE = "https://api.openweathermap.org/data/2.5"
ICON_URL = "https://openweathermap.org/img/wn/{}@2x.png"
THEMES = {"Clear": "#fdd835", "Clouds": "#b0bec5", "Rain": "#64b5f6", "Drizzle": "#81d4fa",
          "Thunderstorm": "#7e57c2", "Snow": "#e1f5fe", "Mist": "#cfd8dc"}


class WeatherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Weather App")
        self.geometry("560x520")
        self.images = []  # keep references so icons are not garbage collected
        self.unit = tk.StringVar(value="C")
        self.last = None

        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")
        ttk.Label(top, text="City / ZIP:").pack(side="left")
        self.city = ttk.Entry(top, width=22)
        self.city.pack(side="left", padx=5)
        self.city.bind("<Return>", lambda e: self.search())
        ttk.Button(top, text="Search", command=self.search).pack(side="left")
        ttk.Radiobutton(top, text="°C", variable=self.unit, value="C", command=self.render).pack(side="left", padx=(12, 0))
        ttk.Radiobutton(top, text="°F", variable=self.unit, value="F", command=self.render).pack(side="left")

        key_row = ttk.Frame(self, padding=(10, 0))
        key_row.pack(fill="x")
        ttk.Label(key_row, text="API key:").pack(side="left")
        self.key = ttk.Entry(key_row, width=40, show="*")
        self.key.insert(0, os.getenv("OPENWEATHER_API_KEY", ""))
        self.key.pack(side="left", padx=5)

        self.panel = tk.Frame(self, bg="#eceff1", height=210)
        self.panel.pack(fill="x", padx=10, pady=10)
        self.icon_lbl = tk.Label(self.panel, bg="#eceff1")
        self.icon_lbl.pack(side="left", padx=15)
        self.info = tk.Label(self.panel, text="Search for a city", bg="#eceff1", font=("Arial", 13), justify="left")
        self.info.pack(side="left")

        self.fc_frame = ttk.Frame(self, padding=10)
        self.fc_frame.pack(fill="both", expand=True)
        self.status = ttk.Label(self, text="", foreground="#c62828")
        self.status.pack(pady=4)

    # ---- helpers
    def conv(self, c):
        return round(c * 9 / 5 + 32) if self.unit.get() == "F" else round(c)

    def get_icon(self, code):
        raw = requests.get(ICON_URL.format(code), timeout=8).content
        return Image.open(io.BytesIO(raw)).convert("RGBA")

    def search(self):
        city, key = self.city.get().strip(), self.key.get().strip()
        if not city:
            messagebox.showwarning("Input", "Please enter a city name or ZIP code.")
            return
        if not key:
            messagebox.showwarning("API key", "Please enter your OpenWeatherMap API key.")
            return
        self.status.config(text="Loading...", foreground="#555")
        threading.Thread(target=self.fetch, args=(city, key), daemon=True).start()

    def fetch(self, city, key):
        params = {"appid": key, "units": "metric"}
        params["zip" if city.isdigit() else "q"] = f"{city},IN" if city.isdigit() else city
        try:
            cur = requests.get(f"{BASE}/weather", params=params, timeout=8)
            if cur.status_code != 200:
                msg = {401: "Invalid API key.", 404: "City not found."}.get(cur.status_code, f"API error {cur.status_code}")
                return self.after(0, lambda: self.status.config(text=msg, foreground="#c62828"))
            fc = requests.get(f"{BASE}/forecast", params=params, timeout=8).json()
            cur = cur.json()
            icons = {cur["weather"][0]["icon"]}
            days = OrderedDict()
            for item in fc.get("list", []):
                d = item["dt_txt"][:10]
                if d not in days or "12:00" in item["dt_txt"]:
                    days[d] = item
            days = list(days.values())[:5]
            icons |= {d["weather"][0]["icon"] for d in days}
            pics = {c: self.get_icon(c) for c in icons}
            self.last = (cur, days, pics)
            self.after(0, self.render)
        except requests.exceptions.Timeout:
            self.after(0, lambda: self.status.config(text="Network timeout.", foreground="#c62828"))
        except requests.exceptions.RequestException:
            self.after(0, lambda: self.status.config(text="Network error. Check internet.", foreground="#c62828"))

    def render(self):
        if not self.last:
            return
        cur, days, pics = self.last
        self.status.config(text="")
        self.images = []
        u = self.unit.get()
        main = cur["weather"][0]["main"]
        bg = THEMES.get(main, "#eceff1")
        self.panel.config(bg=bg)
        big = ImageTk.PhotoImage(pics[cur["weather"][0]["icon"]])
        self.images.append(big)
        self.icon_lbl.config(image=big, bg=bg)
        self.info.config(bg=bg, text=(
            f"{cur['name']}, {cur['sys'].get('country', '')}\n"
            f"{self.conv(cur['main']['temp'])}°{u}  -  {cur['weather'][0]['description'].title()}\n"
            f"Feels like {self.conv(cur['main']['feels_like'])}°{u}\n"
            f"Humidity {cur['main']['humidity']}%   Wind {cur['wind']['speed']} m/s"))
        for w in self.fc_frame.winfo_children():
            w.destroy()
        for i, d in enumerate(days):
            box = ttk.Frame(self.fc_frame, padding=4)
            box.grid(row=0, column=i, padx=4)
            ttk.Label(box, text=datetime.strptime(d["dt_txt"][:10], "%Y-%m-%d").strftime("%a")).pack()
            small = ImageTk.PhotoImage(pics[d["weather"][0]["icon"]].resize((50, 50)))
            self.images.append(small)
            ttk.Label(box, image=small).pack()
            ttk.Label(box, text=f"{self.conv(d['main']['temp'])}°{u}").pack()
            ttk.Label(box, text=d["weather"][0]["main"]).pack()


if __name__ == "__main__":
    WeatherApp().mainloop()
